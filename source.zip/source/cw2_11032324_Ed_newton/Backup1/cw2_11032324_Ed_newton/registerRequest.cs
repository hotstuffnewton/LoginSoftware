﻿/* FEATURES
 * you can make a new account that can accsess the data base.
 * user id must be uniqe and will error and tell you it needs to be if you didnt enter one in.
 * cancel sends you back to the menu, you can also press esc to do that.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;                                            // IMPORTS DO NOT TOUCH
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace cw2_11032324_Ed_newton
{
    public partial class registerRequest : Form
    {
        String connectionString; // makes the connection to the datebase
        OleDbConnection con; // con can now be used to make a connection
        DataSet ds; // used to set data
        String sql; // used to set what table to open
        OleDbCommand cmd; // used to start a command
        OleDbDataAdapter da; // converts data 
        BindingSource bs; // saves new data

        string name; 
        string surname;
        string address;
        string townCity;
        string region;   // strings that will save values from their corosponding text boxes when submit is pressed 
        string postCode;
        string email;
        string phoneNumber;
        string userId;
        string password;
        string passwordCheck;

        bool correctPassword; // these bool variables are used to tell the computer that all information is correct and can now be submited to the data base
        bool correctFields;
        bool correctUserId;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public registerRequest()
        {
            InitializeComponent();
        }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void cancelButton_Click(object sender, EventArgs e) // cancel button
        {
            { 
             this.Close(); // user has clicked cancel close window.
            }
        }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void submitButton_Click(object sender, EventArgs e) // submit button
        {
            name = namebox.Text;
            surname = surnamebox.Text;  // set all value of strings to match that of the text boxes
            address = addressbox.Text;
            townCity = towncitybox.Text;
            region = regionbox.Text;
            postCode = postcodebox.Text;
            email = emailbox.Text;
            phoneNumber = phonenumberbox.Text;
            userId = useridbox.Text;
            password = passwordbox1.Text;
            passwordCheck = passwordbox2.Text;

            correctUserId = true; // userid is correct unless told otherwise. see below.

            if (name.Length <= 0 || surname.Length <= 0 || address.Length <= 0 || townCity.Length <= 0 || postCode.Length <= 0 || phoneNumber.Length <=0) // checked something has been enter in the required fields 
            {
                MessageBox.Show("A required field was empty. Try again please.", "ERROR", MessageBoxButtons.OK); // one or more have not 
                correctFields = false; // user can't progress 
                
            }
            else if (name.Length > 0 || surname.Length > 0 || address.Length > 0 || townCity.Length > 0 || postCode.Length > 0 || phoneNumber.Length > 0) // everything has something entered in it
            {
            correctFields = true; // the user can now progress
            }
                

            if (password == passwordCheck) // do the passwords match? used just incase user has missed type password.
            {
                //do nothing its correct
                correctPassword = true;
            }
            else
            { // they do not match, show warning box.
                MessageBox.Show("Passwords dont match. Try again please.", "ERROR", MessageBoxButtons.OK); 
                
                    password = null; //reset values saved under the strings
                    passwordCheck = null;
                    passwordbox1.Text = null;  // clears the values in the boxes
                    passwordbox2.Text = null;
                    correctPassword = false; // makes sure a loop/error doesn't appear.
                
            }

            if (userId.Length <= 0) // nothing has been entered
            {
                correctUserId = false; // stops user from causing an error and then tells them about it
                MessageBox.Show("You need to enter a unique user ID.", "ERROR", MessageBoxButtons.OK); // one or more have not 

            }
            else // user has entered something into the id
            {
                OleDbCommand command = new OleDbCommand(); // new command
                command.CommandText = "SELECT staffID FROM staff"; // get the staff id collum from the staff table
                command.Connection = con; // set var

 
                    con.Open(); // open the conncetion
                    OleDbDataReader dr = command.ExecuteReader(); // set up a datareader

                        while (dr.Read()) // while the data is being read
                        {

                            for (int i = 0; i < bs.Count; i++) // create a loop
                            {
                                if (userId == dr["staffID"].ToString()) // if the user id is already in the database 
                                {
                                    correctUserId = false; // stops an error from being caused
                                    useridbox.Text = null; // clear the text box
                                    userId = null; // clear the var
                                    //tell the user whats going on and why
                                    MessageBox.Show("Sorry that user name is already in use. Please try again.", "ERROR", MessageBoxButtons.OK);
                                }

                            }
                        }
                    
                    con.Close(); // close connection either because id is correct or incorrect 
            }

            if (correctFields == true && correctUserId == true && correctPassword == true) // everything entered is correct and the information may now be saved.
            { 

                con.Open(); // open a connection to the database

                // first finds the table and fields that the user wants to change/delete and sets the variable that the new information can be added too.
                System.Data.OleDb.OleDbCommand accessInsertCommand = new System.Data.OleDb.OleDbCommand("INSERT INTO staff (staffID, Name, Surname, Address, Town, Region, Postcode, Email, PhoneNumber, AccPassword) VALUES (@staffID, @Name, @Surname, @Address, @Town, @Region, @Postcode, @Email, @PhoneNumber, @AccPassword)", con);
                accessInsertCommand.Parameters.AddWithValue("staffID", userId);// the varibale entered in the text box and saved under userId is now added to the database under the staff table
                accessInsertCommand.Parameters.AddWithValue("Name", name); // the same happens for all fields within the database 
                accessInsertCommand.Parameters.AddWithValue("Surname", surname);
                accessInsertCommand.Parameters.AddWithValue("Address", address);
                accessInsertCommand.Parameters.AddWithValue("Town", townCity);
                accessInsertCommand.Parameters.AddWithValue("Region", region);
                accessInsertCommand.Parameters.AddWithValue("Postcode", postCode);
                accessInsertCommand.Parameters.AddWithValue("Email", email);
                accessInsertCommand.Parameters.AddWithValue("PhoneNumber", phoneNumber);
                accessInsertCommand.Parameters.AddWithValue("AccPassword", password);

                da.InsertCommand = accessInsertCommand; // gets the command to add and save the data
                da.InsertCommand.ExecuteNonQuery(); // saves it

                con.Close(); // closes the connnection

                //clears all the tables in the dataset
                ds.Clear();

                //refills the staff table
                da.Fill(ds, "staff");

                MessageBox.Show("Record Added");
                this.Close(); // closes the window
            }

        }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void registerRequest_Load(object sender, EventArgs e) // the window had been opened
        {
            connectionString = StaticConnectionString.connectionString; // set the right address for the database and conncetion string
            con = new OleDbConnection(connectionString); // con will conncet to the database address given

            con.Open(); // opens the conection
            ds = new DataSet(); // creates a new data set
            sql = "SELECT * FROM staff"; // in the staff table
            cmd = con.CreateCommand(); // command given to make the new dataset
            da = new OleDbDataAdapter(sql, con); // makes sure the data entered is converted correctly
            da.Fill(ds, "staff"); // gets the data base ready to enter new data
            bs = new BindingSource(); // saves the data
            bs.DataSource = ds.Tables["staff"]; // saves the table
            con.Close(); // closes the connection
        }
    }
}
