﻿namespace cw2_11032324_Ed_newton
{
    partial class LogInScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogInScreen));
            this.logInTitleImage = new System.Windows.Forms.PictureBox();
            this.userIDtextbox = new System.Windows.Forms.TextBox();
            this.userIDlable = new System.Windows.Forms.Label();
            this.passWordtextbox = new System.Windows.Forms.TextBox();
            this.passWorddLable = new System.Windows.Forms.Label();
            this.logInButton = new System.Windows.Forms.Button();
            this.registerButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logInTitleImage)).BeginInit();
            this.SuspendLayout();
            // 
            // logInTitleImage
            // 
            this.logInTitleImage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logInTitleImage.BackgroundImage")));
            this.logInTitleImage.ErrorImage = null;
            this.logInTitleImage.Location = new System.Drawing.Point(102, 12);
            this.logInTitleImage.Name = "logInTitleImage";
            this.logInTitleImage.Size = new System.Drawing.Size(624, 181);
            this.logInTitleImage.TabIndex = 0;
            this.logInTitleImage.TabStop = false;
            // 
            // userIDtextbox
            // 
            this.userIDtextbox.Location = new System.Drawing.Point(322, 231);
            this.userIDtextbox.Name = "userIDtextbox";
            this.userIDtextbox.Size = new System.Drawing.Size(183, 20);
            this.userIDtextbox.TabIndex = 1;
            // 
            // userIDlable
            // 
            this.userIDlable.AutoSize = true;
            this.userIDlable.Location = new System.Drawing.Point(267, 234);
            this.userIDlable.Name = "userIDlable";
            this.userIDlable.Size = new System.Drawing.Size(49, 13);
            this.userIDlable.TabIndex = 2;
            this.userIDlable.Text = "User ID: ";
            // 
            // passWordtextbox
            // 
            this.passWordtextbox.Location = new System.Drawing.Point(322, 275);
            this.passWordtextbox.Name = "passWordtextbox";
            this.passWordtextbox.Size = new System.Drawing.Size(183, 20);
            this.passWordtextbox.TabIndex = 3;
            // 
            // passWorddLable
            // 
            this.passWorddLable.AutoSize = true;
            this.passWorddLable.Location = new System.Drawing.Point(257, 278);
            this.passWorddLable.Name = "passWorddLable";
            this.passWorddLable.Size = new System.Drawing.Size(59, 13);
            this.passWorddLable.TabIndex = 4;
            this.passWorddLable.Text = "Password: ";
            // 
            // logInButton
            // 
            this.logInButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.logInButton.Location = new System.Drawing.Point(594, 258);
            this.logInButton.Name = "logInButton";
            this.logInButton.Size = new System.Drawing.Size(141, 52);
            this.logInButton.TabIndex = 5;
            this.logInButton.Text = "LOG IN";
            this.logInButton.UseVisualStyleBackColor = false;
            this.logInButton.Click += new System.EventHandler(this.logInButton_Click);
            // 
            // registerButton
            // 
            this.registerButton.BackColor = System.Drawing.Color.Teal;
            this.registerButton.Location = new System.Drawing.Point(594, 339);
            this.registerButton.Name = "registerButton";
            this.registerButton.Size = new System.Drawing.Size(141, 52);
            this.registerButton.TabIndex = 6;
            this.registerButton.Text = "REGISTER";
            this.registerButton.UseVisualStyleBackColor = false;
            this.registerButton.Click += new System.EventHandler(this.registerButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(12, 356);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(141, 52);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "EXIT";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // LogInScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(797, 420);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.registerButton);
            this.Controls.Add(this.logInButton);
            this.Controls.Add(this.passWorddLable);
            this.Controls.Add(this.passWordtextbox);
            this.Controls.Add(this.userIDlable);
            this.Controls.Add(this.userIDtextbox);
            this.Controls.Add(this.logInTitleImage);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(813, 458);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(813, 458);
            this.Name = "LogInScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LogIn";
            this.Load += new System.EventHandler(this.LogInScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logInTitleImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logInTitleImage;
        private System.Windows.Forms.TextBox userIDtextbox;
        private System.Windows.Forms.Label userIDlable;
        private System.Windows.Forms.TextBox passWordtextbox;
        private System.Windows.Forms.Label passWorddLable;
        private System.Windows.Forms.Button logInButton;
        private System.Windows.Forms.Button registerButton;
        private System.Windows.Forms.Button exitButton;

    }
}

