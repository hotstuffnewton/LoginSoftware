﻿/* FEATURES
 * if you had a customer up in the previous form, all the accounts you see by pressing next will linked to them and only them.
 * you can change and save certain things in the form. errors if you enter nothing and tells you about it.
 * delte and newaccoutn do nothing for now.
 * once all account have been shown the next but takes you back to the first accounts and repeates.
 * exit send you back to the menu, you can also press esc to do that.
 * ERROR....
 * if nothing was selected in the form before i.e. a customer id clicking next to see a linked account will crasht he program.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
namespace cw2_11032324_Ed_newton
{
    public partial class Accounts : Form
    {
        String connectionString; // makes the connection to the datebase
        OleDbConnection con; // used to read the data
        OleDbConnection con2; // used to update/edit/delete data
        OleDbCommand cmd; // used to start a command
        OleDbDataReader dr; // read data

        string customerId;
        string accountNumber;
        string accType;  // strings to hold data from database
        string accBalance;
        string accOverdraft;
        string locked;

        int result; // used to confirm results

        string customerIDCheck; // used to stop records being shown on different customers 
        bool something;

/////////////////////////////////////////////////////////////////////////////////////////////////////////
        public Accounts(string customerID) // imports the value of customerId
        {
            InitializeComponent();
            customerId = customerID; // sets value under new var
        }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void exitButton_Click(object sender, EventArgs e) // exit button
        {
            this.Close();// window closes 
        }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Accounts_Load(object sender, EventArgs e) // runs code on window load
        {
            connectionString = StaticConnectionString.connectionString; // set the right address for the database and conncetion string
            con = new OleDbConnection(connectionString); // con will conncet to the database address given
            con.Open(); // open connection
            cmd = new OleDbCommand();
            cmd.CommandText = "SELECT * FROM Account;";
            cmd.Connection = con;
            dr = cmd.ExecuteReader();

            accountTypebox.Items.Add("CURRENT");
            accountTypebox.Items.Add("SAVINGS");
            accountlockedbox.Items.Add("True");
            accountlockedbox.Items.Add("False");

            customerIDbox.Text = customerId;
            
        }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void saveButton_Click(object sender, EventArgs e) // save button
        {
            accountNumber = accountnumberbox.Text;
            accType = accountTypebox.Text; // all vars now have the value entered in the text boxes
            accBalance = balancebox.Text;
            accOverdraft = overdraftbox.Text;
            locked = statuslb.Text;

            con2 = new OleDbConnection(connectionString); // make connection 2 stops errors

            if (accType.Length <= 0 || accOverdraft.Length <= 0 || locked.Length <= 0) // nothing entered in required 
            {
                MessageBox.Show("Required field empty. Try again please"); //error
            }
            else // something entered
            {
                con2.Open(); // open the connection
                cmd.CommandText = @"UPDATE Account SET accType = @accType, accOverdraft = @accOverdraft, acclocked = @acclocked WHERE accountNumber = @accountNumber"; // update fields
                cmd.Connection = con2; // link command to the connection
                cmd.Parameters.AddWithValue("accType", accType); // the same happens for all fields within the database 
                cmd.Parameters.AddWithValue("accOverdraft", accOverdraft);
                cmd.Parameters.AddWithValue("acclocked", locked);
                cmd.Parameters.AddWithValue("accountNumber", accountNumber);
                result = cmd.ExecuteNonQuery(); // if the data is updated the result value pluses one.
                if (result > 0)
                { // if the result has been plused by one 
                    MessageBox.Show("Data was updated"); // everything has worked
                    con2.Close(); // close connection.
                }
                else
                {
                    MessageBox.Show("Data wasnt updated"); // error
                    con2.Close(); // close connection
                }

            }
        }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void nextButton_Click(object sender, EventArgs e) // next button
        {
            something = false; // button clicked ser to false

           while(something == false){ // start loop

                if (dr.Read()) // read accounts and save 
                {
                    customerIDCheck = dr["customerID"].ToString();
                    accountNumber = dr["accountNumber"].ToString();
                    accType = dr["accType"].ToString();
                    accBalance = dr["accBalance"].ToString();     // saves all values under strings
                    accOverdraft = dr["accOverdraft"].ToString();
                    locked = dr["accLocked"].ToString();
                }

                if (customerId == customerIDCheck) // check to see if the account is connected to the customer
                {
                    something = true; // it is break loop
                }
                 // if it isnt keep looping
                if (something == true)
                {
                    accountnumberbox.Text = accountNumber; // show the data in teh boxes
                    accountTypebox.Text = accType;
                    balancebox.Text = accBalance;
                    overdraftbox.Text = accOverdraft;
                    accountlockedbox.Text = locked;
                }
        }
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Accounts_FormClosing(object sender, FormClosingEventArgs e) // starts when window is closing
        {
            // Close data reader object and database connection when the window closes. stops errors 
            if (dr != null)
                dr.Close();

            if (con.State == ConnectionState.Open)
                con.Close();
        }

        private void deletebutton_Click(object sender, EventArgs e) // delte button
        {

        }
    }
}