﻿/* FEATURES
 * all the buttons take you to a new form where you can perform said tasks the button indicates
 * logout send you back to the menu, you can also press esc to do that.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace cw2_11032324_Ed_newton
{
    public partial class MenuScreen : Form
    {
        string loggedIn; // used to trasfer the value to the settings page

        public MenuScreen(string userId) // imports the userId used from the login form
        {
            InitializeComponent();
            loggedIn = userId; // logged in now has the same and correct value.
        }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void settingsButton_Click(object sender, EventArgs e) // setting button
        {
            UserSettings vc; // settings button has been clicked on.
            vc = new UserSettings(loggedIn); // open up the settings window
            vc.ShowDialog();
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void logOutButton_Click(object sender, EventArgs e) // log out button
        {
            { 
                this.Close(); // user has clicked log out, close window.
            }
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void addCustomerButton_Click(object sender, EventArgs e) // add customer button
        {
            addCustomer vc; //  button has been clicked on.
            vc = new addCustomer(); // open up the settings window
            vc.ShowDialog();
        }

        private void deleteCustomerButton_Click(object sender, EventArgs e) // delete customer button
        {
            deleteCustomer vc; //  button has been clicked on.
            vc = new deleteCustomer(); // open up the settings window
            vc.ShowDialog();
        }

        private void veiwCustomerButton_Click(object sender, EventArgs e) // veiw customer button
        {
            veiwCustomer vc; //  button has been clicked on.
            vc = new veiwCustomer(); // open up the window
            vc.ShowDialog();
        }
    }
}
