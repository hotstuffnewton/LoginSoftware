﻿namespace cw2_11032324_Ed_newton
{
    partial class addCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addCustomer));
            this.notebox = new System.Windows.Forms.Label();
            this.cancelButton = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.phoneNumberlable = new System.Windows.Forms.Label();
            this.phonenumberbox = new System.Windows.Forms.TextBox();
            this.emaillable = new System.Windows.Forms.Label();
            this.emailbox = new System.Windows.Forms.TextBox();
            this.postcodelable = new System.Windows.Forms.Label();
            this.postcodebox = new System.Windows.Forms.TextBox();
            this.regionlable = new System.Windows.Forms.Label();
            this.regionbox = new System.Windows.Forms.TextBox();
            this.towncitylable = new System.Windows.Forms.Label();
            this.towncitybox = new System.Windows.Forms.TextBox();
            this.addresslable = new System.Windows.Forms.Label();
            this.addressbox = new System.Windows.Forms.TextBox();
            this.surnamelable = new System.Windows.Forms.Label();
            this.surnamebox = new System.Windows.Forms.TextBox();
            this.namelable = new System.Windows.Forms.Label();
            this.namebox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // notebox
            // 
            this.notebox.AutoSize = true;
            this.notebox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notebox.ForeColor = System.Drawing.Color.Black;
            this.notebox.Location = new System.Drawing.Point(346, 230);
            this.notebox.Name = "notebox";
            this.notebox.Size = new System.Drawing.Size(163, 24);
            this.notebox.TabIndex = 52;
            this.notebox.Text = "* = Required Field";
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(321, 31);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(227, 68);
            this.cancelButton.TabIndex = 51;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.submitButton.Location = new System.Drawing.Point(321, 105);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(227, 68);
            this.submitButton.TabIndex = 44;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // phoneNumberlable
            // 
            this.phoneNumberlable.AutoSize = true;
            this.phoneNumberlable.Location = new System.Drawing.Point(9, 293);
            this.phoneNumberlable.Name = "phoneNumberlable";
            this.phoneNumberlable.Size = new System.Drawing.Size(82, 13);
            this.phoneNumberlable.TabIndex = 43;
            this.phoneNumberlable.Text = "Phone Number*";
            // 
            // phonenumberbox
            // 
            this.phonenumberbox.Location = new System.Drawing.Point(93, 290);
            this.phonenumberbox.Name = "phonenumberbox";
            this.phonenumberbox.Size = new System.Drawing.Size(198, 20);
            this.phonenumberbox.TabIndex = 42;
            // 
            // emaillable
            // 
            this.emaillable.AutoSize = true;
            this.emaillable.Location = new System.Drawing.Point(52, 267);
            this.emaillable.Name = "emaillable";
            this.emaillable.Size = new System.Drawing.Size(35, 13);
            this.emaillable.TabIndex = 41;
            this.emaillable.Text = "E-mail";
            // 
            // emailbox
            // 
            this.emailbox.Location = new System.Drawing.Point(93, 264);
            this.emailbox.Name = "emailbox";
            this.emailbox.Size = new System.Drawing.Size(198, 20);
            this.emailbox.TabIndex = 40;
            // 
            // postcodelable
            // 
            this.postcodelable.AutoSize = true;
            this.postcodelable.Location = new System.Drawing.Point(38, 211);
            this.postcodelable.Name = "postcodelable";
            this.postcodelable.Size = new System.Drawing.Size(56, 13);
            this.postcodelable.TabIndex = 39;
            this.postcodelable.Text = "Postcode*";
            // 
            // postcodebox
            // 
            this.postcodebox.Location = new System.Drawing.Point(93, 208);
            this.postcodebox.Name = "postcodebox";
            this.postcodebox.Size = new System.Drawing.Size(198, 20);
            this.postcodebox.TabIndex = 38;
            // 
            // regionlable
            // 
            this.regionlable.AutoSize = true;
            this.regionlable.Location = new System.Drawing.Point(46, 171);
            this.regionlable.Name = "regionlable";
            this.regionlable.Size = new System.Drawing.Size(41, 13);
            this.regionlable.TabIndex = 37;
            this.regionlable.Text = "Region";
            // 
            // regionbox
            // 
            this.regionbox.Location = new System.Drawing.Point(93, 168);
            this.regionbox.Name = "regionbox";
            this.regionbox.Size = new System.Drawing.Size(198, 20);
            this.regionbox.TabIndex = 36;
            // 
            // towncitylable
            // 
            this.towncitylable.AutoSize = true;
            this.towncitylable.Location = new System.Drawing.Point(31, 145);
            this.towncitylable.Name = "towncitylable";
            this.towncitylable.Size = new System.Drawing.Size(60, 13);
            this.towncitylable.TabIndex = 35;
            this.towncitylable.Text = "Town/City*";
            // 
            // towncitybox
            // 
            this.towncitybox.Location = new System.Drawing.Point(93, 142);
            this.towncitybox.Name = "towncitybox";
            this.towncitybox.Size = new System.Drawing.Size(198, 20);
            this.towncitybox.TabIndex = 34;
            // 
            // addresslable
            // 
            this.addresslable.AutoSize = true;
            this.addresslable.Location = new System.Drawing.Point(42, 107);
            this.addresslable.Name = "addresslable";
            this.addresslable.Size = new System.Drawing.Size(49, 13);
            this.addresslable.TabIndex = 33;
            this.addresslable.Text = "Address*";
            // 
            // addressbox
            // 
            this.addressbox.Location = new System.Drawing.Point(93, 104);
            this.addressbox.Name = "addressbox";
            this.addressbox.Size = new System.Drawing.Size(198, 20);
            this.addressbox.TabIndex = 32;
            // 
            // surnamelable
            // 
            this.surnamelable.AutoSize = true;
            this.surnamelable.Location = new System.Drawing.Point(38, 63);
            this.surnamelable.Name = "surnamelable";
            this.surnamelable.Size = new System.Drawing.Size(53, 13);
            this.surnamelable.TabIndex = 31;
            this.surnamelable.Text = "Surname*";
            // 
            // surnamebox
            // 
            this.surnamebox.Location = new System.Drawing.Point(93, 60);
            this.surnamebox.Name = "surnamebox";
            this.surnamebox.Size = new System.Drawing.Size(198, 20);
            this.surnamebox.TabIndex = 30;
            // 
            // namelable
            // 
            this.namelable.AutoSize = true;
            this.namelable.Location = new System.Drawing.Point(52, 34);
            this.namelable.Name = "namelable";
            this.namelable.Size = new System.Drawing.Size(39, 13);
            this.namelable.TabIndex = 29;
            this.namelable.Text = "Name*";
            // 
            // namebox
            // 
            this.namebox.Location = new System.Drawing.Point(93, 31);
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(198, 20);
            this.namebox.TabIndex = 28;
            // 
            // addCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(577, 339);
            this.Controls.Add(this.notebox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.phoneNumberlable);
            this.Controls.Add(this.phonenumberbox);
            this.Controls.Add(this.emaillable);
            this.Controls.Add(this.emailbox);
            this.Controls.Add(this.postcodelable);
            this.Controls.Add(this.postcodebox);
            this.Controls.Add(this.regionlable);
            this.Controls.Add(this.regionbox);
            this.Controls.Add(this.towncitylable);
            this.Controls.Add(this.towncitybox);
            this.Controls.Add(this.addresslable);
            this.Controls.Add(this.addressbox);
            this.Controls.Add(this.surnamelable);
            this.Controls.Add(this.surnamebox);
            this.Controls.Add(this.namelable);
            this.Controls.Add(this.namebox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(593, 377);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(593, 377);
            this.Name = "addCustomer";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Customer Form";
            this.Load += new System.EventHandler(this.addCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label notebox;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label phoneNumberlable;
        private System.Windows.Forms.TextBox phonenumberbox;
        private System.Windows.Forms.Label emaillable;
        private System.Windows.Forms.TextBox emailbox;
        private System.Windows.Forms.Label postcodelable;
        private System.Windows.Forms.TextBox postcodebox;
        private System.Windows.Forms.Label regionlable;
        private System.Windows.Forms.TextBox regionbox;
        private System.Windows.Forms.Label towncitylable;
        private System.Windows.Forms.TextBox towncitybox;
        private System.Windows.Forms.Label addresslable;
        private System.Windows.Forms.TextBox addressbox;
        private System.Windows.Forms.Label surnamelable;
        private System.Windows.Forms.TextBox surnamebox;
        private System.Windows.Forms.Label namelable;
        private System.Windows.Forms.TextBox namebox;
    }
}