﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Using a static class to contain the connection string allows each form quick access
//to the database connection string - it is also much easier to change location of DB
namespace cw2_11032324_Ed_newton
{
    static class StaticConnectionString
    {
        public static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Ed\\Documents\\UNI WORK!!\\YEAR 2\\computer programming\\cw2\\BoG_SE2S551.accdb";
    }
}
