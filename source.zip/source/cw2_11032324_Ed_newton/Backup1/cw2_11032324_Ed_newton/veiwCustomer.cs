﻿/* FEATURES
 * you can see each customer and their details by pressing the next button.
 * once you reach a point where nothing changes after clicking the next button you press the reset button to go over the data again.
 * clicking save will update what ever has been enter in the text boxes to their corrosponding fields, if nothing is entered in a required field the code tells you and dose not save.
 * clicking accounts will bring up a window with all the accounts linked the customerid that was displayed last.
 * exit send you back to the menu, you can also press esc to do that.
 * ERRORS.........      
 * clciking account when nothing is in the text boxes causes a crash.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace cw2_11032324_Ed_newton
{
    public partial class veiwCustomer : Form
    {
        String connectionString; // makes the connection to the datebase
        OleDbConnection con; // used to read the data
        OleDbConnection con2; // used to update/edit/delete data
        OleDbCommand cmd; // used to start a command
        OleDbDataReader dr; // read data

        string name;
        string surname;
        string address;
        string townCity;
        string region;   // strings that will save values from their corosponding text boxes when submit is pressed 
        string postCode;
        string email;
        string phoneNumber;
        string customerID;

        int result; // used to confirm results

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public veiwCustomer()
        {
            InitializeComponent();
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void veiwCustomer_Load(object sender, EventArgs e) // when the windows opens 
        {
            connectionString = StaticConnectionString.connectionString; // set the right address for the database and conncetion string
            con = new OleDbConnection(connectionString); // con will conncet to the database address given
            con.Open(); // open connection
            cmd = new OleDbCommand();
            cmd.CommandText = "SELECT * FROM Customer;";
            cmd.Connection = con;
            dr = cmd.ExecuteReader();
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void exitButton_Click(object sender, EventArgs e) // exit button
        {
            this.Close(); // close window
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void saveButton_Click(object sender, EventArgs e) // save button
        {
            name = namebox.Text;
            surname = surnamebox.Text;
            address = addressbox.Text;
            townCity = towncitybox.Text;
            region = regionbox.Text;   // strings that will save values from their corosponding text boxes when submit is pressed 
            postCode = postcodebox.Text;
            email = emailbox.Text;
            phoneNumber = phonenumberbox.Text;
            customerID = customerIDbox.Text;

            con2 = new OleDbConnection(connectionString);

            if (name.Length <= 0 || surname.Length <= 0 || address.Length <= 0 || townCity.Length <= 0 || postCode.Length <= 0 || phoneNumber.Length <= 0)
            {
                MessageBox.Show("Required field empty. Try again please");
            }
            else
            {
                con2.Open();
                cmd.CommandText = @"UPDATE Customer SET Name = @Name, Surname = @Surname, Address = @Address, Town = @Town, Region = @Region, Postcode = @Postcode, Email = @Email, PhoneNumber = @PhoneNumber WHERE customerID = @customerID"; // delete the staffid that holds the same value of @staffID
                cmd.Connection = con2; // link command to the connection
                cmd.Parameters.AddWithValue("Name", name); // the same happens for all fields within the database 
                cmd.Parameters.AddWithValue("Surname", surname);
                cmd.Parameters.AddWithValue("Address", address);
                cmd.Parameters.AddWithValue("Town", townCity);
                cmd.Parameters.AddWithValue("Region", region);
                cmd.Parameters.AddWithValue("Postcode", postCode);
                cmd.Parameters.AddWithValue("Email", email);
                cmd.Parameters.AddWithValue("PhoneNumber", phoneNumber);
                cmd.Parameters.AddWithValue("customerID", customerID);
                result = cmd.ExecuteNonQuery(); // if the data is updated the result value pluses one.
                if (result > 0)
                { // if the result has been plused by one 
                    MessageBox.Show("Data was updated"); // everything has worked
                    con2.Close(); // close connection.
                }
                else
                {
                    MessageBox.Show("Data wasnt updated"); // error
                    con2.Close(); // close connection
                }
            }
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void nextButton_Click(object sender, EventArgs e) // next button
        {
            if (dr.Read())//Read the next row
            {
                customerIDbox.Text = dr["CustomerID"].ToString();
                namebox.Text = dr["Name"].ToString();
                surnamebox.Text = dr["Surname"].ToString();
                addressbox.Text = dr["Address"].ToString(); // show all details of the customer in the text boxes
                towncitybox.Text = dr["Town"].ToString();
                regionbox.Text = dr["Region"].ToString();
                postcodebox.Text = dr["Postcode"].ToString();
                emailbox.Text = dr["Email"].ToString();
                phonenumberbox.Text = dr["PhoneNumber"].ToString();

            }
            
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void veiwCustomer_FormClosing(object sender, FormClosingEventArgs e) // code starts when window is closing
        {
            // Close data reader object and database connection when the window closes. stops errors 
            if (dr != null)
                dr.Close();

            if (con.State == ConnectionState.Open)
                con.Close();
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void accountsButton_Click(object sender, EventArgs e) // accounts button
        {
            customerID = customerIDbox.Text;

            Accounts vc; //  button has been clicked on.
            vc = new Accounts(customerID); // open up the window
            vc.ShowDialog();
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void reset_Click(object sender, EventArgs e) //reset button
        {
            customerIDbox.Text = null;
            namebox.Text = null;
            surnamebox.Text = null;
            addressbox.Text = null;
            towncitybox.Text = null;
            regionbox.Text = null;
            postcodebox.Text = null;
            emailbox.Text = null;
            phonenumberbox.Text = null;

            dr.Close();
            dr = cmd.ExecuteReader();
        } 
    }
}
