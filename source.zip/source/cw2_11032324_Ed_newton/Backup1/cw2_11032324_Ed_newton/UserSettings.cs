﻿/* FEATURES
 * Typing something in the new passsword text box changes the current users password to just that, if nothing is entered it tells you ro try again.
 * deactivation account deletes the current users data and closes the program.
 * chaning picture button does nothing.
 * return to meun sends you back to the menu, you can also press esc to do that.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;                         //DO NOT TOUCH
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace cw2_11032324_Ed_newton
{
    public partial class UserSettings : Form
    {
        string userId; // used to tell the computer who is currently logged in. (value taken from the login screen)
        string newPassword; // used to change password
        int result; // used to verify that the command was done correctly

        String connectionString; // makes the connection to the datebase
        OleDbConnection con; // con can now be used to make a connection
        DataSet ds; // used to set data
        String sql; // used to set what table to open
        OleDbCommand cmd; // used to start a command
        OleDbDataAdapter da; // converts data 
        BindingSource bs; // saves new data

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public UserSettings(string loggedIn) // imports the value from the main menu which imports from the login screen 
        {
            InitializeComponent();
            userId = loggedIn; // value set and changed to the id of whos logged in.
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void deactivateAccountButton_Click(object sender, EventArgs e) // Deactivate Account button
        {
            if (MessageBox.Show("Are you sure you want to Deactivate your Account?", "Account Deactivation", MessageBoxButtons.YesNo) == DialogResult.Yes) //button has been clicked on.
            { // computer double checks if the user wants to deactiveate their account with a message box.
                
                con.Open(); // open connection
                string sql = "DELETE from staff WHERE staffID = @staffID"; // delete the staffid that holds the same value of @staffID
                cmd = new OleDbCommand(sql, con); 
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("staffID", userId); // sets the value of @staffId to the person that is logged in.
                result = cmd.ExecuteNonQuery(); // if the data is deleted the result value pluses one.
                if (result > 0){ // if the result has been plused by one 
                    MessageBox.Show("Record Deleted"); // everything has worked 
            }
                con.Close(); // close connection
                Application.Exit(); // close app as you no longer have an account
            }
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ReturnToMenuButton_Click(object sender, EventArgs e) // return to menu button
        {
            this.Close(); // close window 
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void UserSettings_Load(object sender, EventArgs e) // the window had been opened
        {
            connectionString = StaticConnectionString.connectionString; // set the right address for the database and conncetion string
            con = new OleDbConnection(connectionString); // con will conncet to the database address given

            con.Open(); // opens the conection
            ds = new DataSet(); // creates a new data set
            sql = "SELECT * FROM staff"; // in the staff table
            cmd = con.CreateCommand(); // command given to make the new dataset
            da = new OleDbDataAdapter(sql, con); // makes sure the data entered is converted correctly
            da.Fill(ds, "staff"); // gets the data base ready to enter new data
            bs = new BindingSource(); // saves the data
            bs.DataSource = ds.Tables["staff"]; // saves the table
            con.Close(); // closes the connection
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void resetPasswordButton_Click(object sender, EventArgs e)// change password button
        {
            newPassword = newPasswordBox.Text;

            if (newPassword.Length <= 0)
            {
                MessageBox.Show("A required field was empty. Try again please.", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                con.Open(); // open connection
                cmd.CommandText = @"UPDATE staff SET AccPassword = @AccPassword WHERE staffID = @staffID"; // delete the staffid that holds the same value of @staffID
                cmd.Connection = con; // link command to the connection 
                cmd.Parameters.AddWithValue("AccPassword", newPassword); // changes password
                cmd.Parameters.AddWithValue("staffID", userId); // makes sure it was the password of who was logged in
                result = cmd.ExecuteNonQuery(); // if the data is updated the result value pluses one.
                if (result > 0)
                { // if the result has been plused by one 
                    MessageBox.Show("Password Updated"); // everything has worked
                    con.Close(); // close connection.
                }
                else
                {
                    MessageBox.Show("Password Not Updated"); // error
                    con.Close(); // close connection
                }
                
            }
        }

    }
}
