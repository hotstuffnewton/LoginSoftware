﻿namespace cw2_11032324_Ed_newton
{
    partial class UserSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserSettings));
            this.resetPasswordButton = new System.Windows.Forms.Button();
            this.deactivateAccountButton = new System.Windows.Forms.Button();
            this.changeImageButton = new System.Windows.Forms.Button();
            this.ReturnToMenuButton = new System.Windows.Forms.Button();
            this.enternewpasswordlable = new System.Windows.Forms.Label();
            this.newPasswordBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // resetPasswordButton
            // 
            this.resetPasswordButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.resetPasswordButton.Location = new System.Drawing.Point(12, 65);
            this.resetPasswordButton.Name = "resetPasswordButton";
            this.resetPasswordButton.Size = new System.Drawing.Size(198, 75);
            this.resetPasswordButton.TabIndex = 2;
            this.resetPasswordButton.Text = "Change Password";
            this.resetPasswordButton.UseVisualStyleBackColor = false;
            this.resetPasswordButton.Click += new System.EventHandler(this.resetPasswordButton_Click);
            // 
            // deactivateAccountButton
            // 
            this.deactivateAccountButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.deactivateAccountButton.Location = new System.Drawing.Point(12, 146);
            this.deactivateAccountButton.Name = "deactivateAccountButton";
            this.deactivateAccountButton.Size = new System.Drawing.Size(198, 75);
            this.deactivateAccountButton.TabIndex = 3;
            this.deactivateAccountButton.Text = "Deactivate Account";
            this.deactivateAccountButton.UseVisualStyleBackColor = false;
            this.deactivateAccountButton.Click += new System.EventHandler(this.deactivateAccountButton_Click);
            // 
            // changeImageButton
            // 
            this.changeImageButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.changeImageButton.Location = new System.Drawing.Point(231, 65);
            this.changeImageButton.Name = "changeImageButton";
            this.changeImageButton.Size = new System.Drawing.Size(198, 75);
            this.changeImageButton.TabIndex = 4;
            this.changeImageButton.Text = "Change Profile Picture";
            this.changeImageButton.UseVisualStyleBackColor = false;
            // 
            // ReturnToMenuButton
            // 
            this.ReturnToMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ReturnToMenuButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.ReturnToMenuButton.Location = new System.Drawing.Point(231, 146);
            this.ReturnToMenuButton.Name = "ReturnToMenuButton";
            this.ReturnToMenuButton.Size = new System.Drawing.Size(198, 75);
            this.ReturnToMenuButton.TabIndex = 5;
            this.ReturnToMenuButton.Text = "Return To Menu";
            this.ReturnToMenuButton.UseVisualStyleBackColor = false;
            this.ReturnToMenuButton.Click += new System.EventHandler(this.ReturnToMenuButton_Click);
            // 
            // enternewpasswordlable
            // 
            this.enternewpasswordlable.AutoSize = true;
            this.enternewpasswordlable.Location = new System.Drawing.Point(47, 23);
            this.enternewpasswordlable.Name = "enternewpasswordlable";
            this.enternewpasswordlable.Size = new System.Drawing.Size(129, 13);
            this.enternewpasswordlable.TabIndex = 6;
            this.enternewpasswordlable.Text = "Enter New password here";
            // 
            // newPasswordBox
            // 
            this.newPasswordBox.Location = new System.Drawing.Point(182, 20);
            this.newPasswordBox.Name = "newPasswordBox";
            this.newPasswordBox.Size = new System.Drawing.Size(187, 20);
            this.newPasswordBox.TabIndex = 7;
            // 
            // UserSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.ReturnToMenuButton;
            this.ClientSize = new System.Drawing.Size(460, 233);
            this.Controls.Add(this.newPasswordBox);
            this.Controls.Add(this.enternewpasswordlable);
            this.Controls.Add(this.ReturnToMenuButton);
            this.Controls.Add(this.changeImageButton);
            this.Controls.Add(this.deactivateAccountButton);
            this.Controls.Add(this.resetPasswordButton);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(476, 271);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(476, 271);
            this.Name = "UserSettings";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.UserSettings_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button resetPasswordButton;
        private System.Windows.Forms.Button deactivateAccountButton;
        private System.Windows.Forms.Button changeImageButton;
        private System.Windows.Forms.Button ReturnToMenuButton;
        private System.Windows.Forms.Label enternewpasswordlable;
        private System.Windows.Forms.TextBox newPasswordBox;
    }
}