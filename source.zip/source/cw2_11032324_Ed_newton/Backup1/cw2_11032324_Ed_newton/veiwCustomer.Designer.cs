﻿namespace cw2_11032324_Ed_newton
{
    partial class veiwCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(veiwCustomer));
            this.phoneNumberlable = new System.Windows.Forms.Label();
            this.phonenumberbox = new System.Windows.Forms.TextBox();
            this.emaillable = new System.Windows.Forms.Label();
            this.emailbox = new System.Windows.Forms.TextBox();
            this.postcodelable = new System.Windows.Forms.Label();
            this.postcodebox = new System.Windows.Forms.TextBox();
            this.regionlable = new System.Windows.Forms.Label();
            this.regionbox = new System.Windows.Forms.TextBox();
            this.towncitylable = new System.Windows.Forms.Label();
            this.towncitybox = new System.Windows.Forms.TextBox();
            this.addresslable = new System.Windows.Forms.Label();
            this.addressbox = new System.Windows.Forms.TextBox();
            this.surnamelable = new System.Windows.Forms.Label();
            this.surnamebox = new System.Windows.Forms.TextBox();
            this.namelable = new System.Windows.Forms.Label();
            this.namebox = new System.Windows.Forms.TextBox();
            this.nextButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.accountsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.customerIDbox = new System.Windows.Forms.TextBox();
            this.IDlabel = new System.Windows.Forms.Label();
            this.reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // phoneNumberlable
            // 
            this.phoneNumberlable.AutoSize = true;
            this.phoneNumberlable.Location = new System.Drawing.Point(5, 301);
            this.phoneNumberlable.Name = "phoneNumberlable";
            this.phoneNumberlable.Size = new System.Drawing.Size(78, 13);
            this.phoneNumberlable.TabIndex = 59;
            this.phoneNumberlable.Text = "Phone Number";
            // 
            // phonenumberbox
            // 
            this.phonenumberbox.Location = new System.Drawing.Point(89, 298);
            this.phonenumberbox.Name = "phonenumberbox";
            this.phonenumberbox.Size = new System.Drawing.Size(198, 20);
            this.phonenumberbox.TabIndex = 58;
            // 
            // emaillable
            // 
            this.emaillable.AutoSize = true;
            this.emaillable.Location = new System.Drawing.Point(48, 275);
            this.emaillable.Name = "emaillable";
            this.emaillable.Size = new System.Drawing.Size(35, 13);
            this.emaillable.TabIndex = 57;
            this.emaillable.Text = "E-mail";
            // 
            // emailbox
            // 
            this.emailbox.Location = new System.Drawing.Point(89, 272);
            this.emailbox.Name = "emailbox";
            this.emailbox.Size = new System.Drawing.Size(198, 20);
            this.emailbox.TabIndex = 56;
            // 
            // postcodelable
            // 
            this.postcodelable.AutoSize = true;
            this.postcodelable.Location = new System.Drawing.Point(34, 219);
            this.postcodelable.Name = "postcodelable";
            this.postcodelable.Size = new System.Drawing.Size(52, 13);
            this.postcodelable.TabIndex = 55;
            this.postcodelable.Text = "Postcode";
            // 
            // postcodebox
            // 
            this.postcodebox.Location = new System.Drawing.Point(89, 216);
            this.postcodebox.Name = "postcodebox";
            this.postcodebox.Size = new System.Drawing.Size(198, 20);
            this.postcodebox.TabIndex = 54;
            // 
            // regionlable
            // 
            this.regionlable.AutoSize = true;
            this.regionlable.Location = new System.Drawing.Point(42, 179);
            this.regionlable.Name = "regionlable";
            this.regionlable.Size = new System.Drawing.Size(41, 13);
            this.regionlable.TabIndex = 53;
            this.regionlable.Text = "Region";
            // 
            // regionbox
            // 
            this.regionbox.Location = new System.Drawing.Point(89, 176);
            this.regionbox.Name = "regionbox";
            this.regionbox.Size = new System.Drawing.Size(198, 20);
            this.regionbox.TabIndex = 52;
            // 
            // towncitylable
            // 
            this.towncitylable.AutoSize = true;
            this.towncitylable.Location = new System.Drawing.Point(27, 153);
            this.towncitylable.Name = "towncitylable";
            this.towncitylable.Size = new System.Drawing.Size(56, 13);
            this.towncitylable.TabIndex = 51;
            this.towncitylable.Text = "Town/City";
            // 
            // towncitybox
            // 
            this.towncitybox.Location = new System.Drawing.Point(89, 150);
            this.towncitybox.Name = "towncitybox";
            this.towncitybox.Size = new System.Drawing.Size(198, 20);
            this.towncitybox.TabIndex = 50;
            // 
            // addresslable
            // 
            this.addresslable.AutoSize = true;
            this.addresslable.Location = new System.Drawing.Point(38, 115);
            this.addresslable.Name = "addresslable";
            this.addresslable.Size = new System.Drawing.Size(45, 13);
            this.addresslable.TabIndex = 49;
            this.addresslable.Text = "Address";
            // 
            // addressbox
            // 
            this.addressbox.Location = new System.Drawing.Point(89, 112);
            this.addressbox.Name = "addressbox";
            this.addressbox.Size = new System.Drawing.Size(198, 20);
            this.addressbox.TabIndex = 48;
            // 
            // surnamelable
            // 
            this.surnamelable.AutoSize = true;
            this.surnamelable.Location = new System.Drawing.Point(34, 71);
            this.surnamelable.Name = "surnamelable";
            this.surnamelable.Size = new System.Drawing.Size(49, 13);
            this.surnamelable.TabIndex = 47;
            this.surnamelable.Text = "Surname";
            // 
            // surnamebox
            // 
            this.surnamebox.Location = new System.Drawing.Point(89, 68);
            this.surnamebox.Name = "surnamebox";
            this.surnamebox.Size = new System.Drawing.Size(198, 20);
            this.surnamebox.TabIndex = 46;
            // 
            // namelable
            // 
            this.namelable.AutoSize = true;
            this.namelable.Location = new System.Drawing.Point(48, 42);
            this.namelable.Name = "namelable";
            this.namelable.Size = new System.Drawing.Size(35, 13);
            this.namelable.TabIndex = 45;
            this.namelable.Text = "Name";
            // 
            // namebox
            // 
            this.namebox.Location = new System.Drawing.Point(89, 39);
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(198, 20);
            this.namebox.TabIndex = 44;
            // 
            // nextButton
            // 
            this.nextButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.nextButton.Location = new System.Drawing.Point(392, 24);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(175, 49);
            this.nextButton.TabIndex = 60;
            this.nextButton.Text = "Next";
            this.nextButton.UseVisualStyleBackColor = false;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.saveButton.Location = new System.Drawing.Point(392, 150);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(175, 49);
            this.saveButton.TabIndex = 62;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // accountsButton
            // 
            this.accountsButton.BackColor = System.Drawing.Color.Teal;
            this.accountsButton.Location = new System.Drawing.Point(392, 219);
            this.accountsButton.Name = "accountsButton";
            this.accountsButton.Size = new System.Drawing.Size(175, 49);
            this.accountsButton.TabIndex = 63;
            this.accountsButton.Text = "Accounts";
            this.accountsButton.UseVisualStyleBackColor = false;
            this.accountsButton.Click += new System.EventHandler(this.accountsButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(392, 301);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(175, 49);
            this.exitButton.TabIndex = 64;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // customerIDbox
            // 
            this.customerIDbox.Location = new System.Drawing.Point(147, 12);
            this.customerIDbox.Name = "customerIDbox";
            this.customerIDbox.ReadOnly = true;
            this.customerIDbox.Size = new System.Drawing.Size(69, 20);
            this.customerIDbox.TabIndex = 65;
            // 
            // IDlabel
            // 
            this.IDlabel.AutoSize = true;
            this.IDlabel.Location = new System.Drawing.Point(123, 15);
            this.IDlabel.Name = "IDlabel";
            this.IDlabel.Size = new System.Drawing.Size(18, 13);
            this.IDlabel.TabIndex = 66;
            this.IDlabel.Text = "ID";
            // 
            // reset
            // 
            this.reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.reset.Location = new System.Drawing.Point(392, 79);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(175, 49);
            this.reset.TabIndex = 67;
            this.reset.Text = "Reset";
            this.reset.UseVisualStyleBackColor = false;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // veiwCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(610, 377);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.IDlabel);
            this.Controls.Add(this.customerIDbox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.accountsButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.phoneNumberlable);
            this.Controls.Add(this.phonenumberbox);
            this.Controls.Add(this.emaillable);
            this.Controls.Add(this.emailbox);
            this.Controls.Add(this.postcodelable);
            this.Controls.Add(this.postcodebox);
            this.Controls.Add(this.regionlable);
            this.Controls.Add(this.regionbox);
            this.Controls.Add(this.towncitylable);
            this.Controls.Add(this.towncitybox);
            this.Controls.Add(this.addresslable);
            this.Controls.Add(this.addressbox);
            this.Controls.Add(this.surnamelable);
            this.Controls.Add(this.surnamebox);
            this.Controls.Add(this.namelable);
            this.Controls.Add(this.namebox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(626, 415);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(626, 415);
            this.Name = "veiwCustomer";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.veiwCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label phoneNumberlable;
        private System.Windows.Forms.TextBox phonenumberbox;
        private System.Windows.Forms.Label emaillable;
        private System.Windows.Forms.TextBox emailbox;
        private System.Windows.Forms.Label postcodelable;
        private System.Windows.Forms.TextBox postcodebox;
        private System.Windows.Forms.Label regionlable;
        private System.Windows.Forms.TextBox regionbox;
        private System.Windows.Forms.Label towncitylable;
        private System.Windows.Forms.TextBox towncitybox;
        private System.Windows.Forms.Label addresslable;
        private System.Windows.Forms.TextBox addressbox;
        private System.Windows.Forms.Label surnamelable;
        private System.Windows.Forms.TextBox surnamebox;
        private System.Windows.Forms.Label namelable;
        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button accountsButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label IDlabel;
        public System.Windows.Forms.TextBox customerIDbox;
        private System.Windows.Forms.Button reset;
    }
}