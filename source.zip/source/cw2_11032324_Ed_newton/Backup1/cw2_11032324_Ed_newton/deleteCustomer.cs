﻿/* FEATURES
 * enter the id you want to delte in the textbox and press submit to do it.
 * if nothing is entered it will error and tell you what was wrong
 * cancel send you back to the menu, you can also press esc to do that.
 * ERROR......
 * entering a customer id that is linked to account will cause the program to crash.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace cw2_11032324_Ed_newton
{
    public partial class deleteCustomer : Form
    {

        String connectionString; // makes the connection to the datebase
        OleDbConnection con; // con can now be used to make a connection
        DataSet ds; // used to set data
        String sql; // used to set what table to open
        OleDbCommand cmd; // used to start a command
        OleDbDataAdapter da; // converts data 
        BindingSource bs; // saves new data

        int result; // need for confirm message
        bool correctCustomer; // need to make sure an error dosent occour

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public deleteCustomer()
        {
            InitializeComponent();
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void cancelButton_Click(object sender, EventArgs e) //cancel button
        {
            this.Close(); // close window.
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void deleteCustomer_Load(object sender, EventArgs e) // starts code when window opens.
        {
            connectionString = StaticConnectionString.connectionString; // set the right address for the database and conncetion string
            con = new OleDbConnection(connectionString); // con will conncet to the database address given

            con.Open(); // opens the conection
            ds = new DataSet(); // creates a new data set
            sql = "SELECT * FROM Customer"; // in the staff table
            cmd = con.CreateCommand(); // command given to make the new dataset
            da = new OleDbDataAdapter(sql, con); // makes sure the data entered is converted correctly
            da.Fill(ds, "Customer"); // gets the data base ready to enter new data
            bs = new BindingSource(); // saves the data
            bs.DataSource = ds.Tables["Customer"]; // saves the table
            con.Close(); // closes the connection
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void submitButton_Click(object sender, EventArgs e) // submit button
        {
            correctCustomer = false; // stops an errors

            if (customerIDBox.Text.Length <= 0)
            {
                MessageBox.Show("Nothing was entered in the box. try again please.", "Error", MessageBoxButtons.OK); // nothing entered show message
            }
            else // something was entered
            {
                OleDbCommand command = new OleDbCommand(); // new command
                command.CommandText = "SELECT customerID FROM Customer"; // find the name 
                command.Connection = con; // set var
                con.Open(); // open the conncetion
                OleDbDataReader dr = command.ExecuteReader(); // set up a datareader

                        while (dr.Read()) // while the data is being read
                        {
                            for (int i = 0; i < bs.Count; i++) // create a loop
                            {
                                if (customerIDBox.Text == dr["customerID"].ToString()) // checks database 
                                {
                                    correctCustomer = true; // confirms that the name is int eh database
                                }
                            }
                        }
                    
                    con.Close(); // close connection 

                    if (correctCustomer == true) // the name is in the data base
                    {

                        if (MessageBox.Show("Are you sure you want to delete this customer?", "Customer Account Deactivation", MessageBoxButtons.YesNo) == DialogResult.Yes) //button has been clicked on.
                        { // computer double checks if the user wants to delete.

                            con.Open(); // open connection
                            string sql = "DELETE from Customer WHERE customerID = @customerID"; // delete the name that holds the same value of @name
                            cmd = new OleDbCommand(sql, con);
                            cmd.CommandType = CommandType.Text;
                            cmd.Parameters.AddWithValue("customerID", customerIDBox.Text); // sets the value of @name 
                            result = cmd.ExecuteNonQuery(); // if the data is deleted the result value pluses one.
                            if (result > 0)
                            { // if the result has been plused by one 
                                MessageBox.Show("Record Deleted"); // everything has worked 
                            }
                            con.Close(); // close connection
                            this.Close(); // close window.
                        }
                    }

                    if (correctCustomer == false && customerIDBox.Text.Length > 0) // name wasnt in the data base
                    {
                        MessageBox.Show("customerID not found. Please try again.", "Error", MessageBoxButtons.OK); // show error
                    }

            }
        }
    }
}
