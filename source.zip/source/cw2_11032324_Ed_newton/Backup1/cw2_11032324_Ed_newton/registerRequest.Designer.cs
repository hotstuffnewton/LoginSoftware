﻿namespace cw2_11032324_Ed_newton
{
    partial class registerRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(registerRequest));
            this.namebox = new System.Windows.Forms.TextBox();
            this.namelable = new System.Windows.Forms.Label();
            this.surnamelable = new System.Windows.Forms.Label();
            this.surnamebox = new System.Windows.Forms.TextBox();
            this.addresslable = new System.Windows.Forms.Label();
            this.addressbox = new System.Windows.Forms.TextBox();
            this.towncitylable = new System.Windows.Forms.Label();
            this.towncitybox = new System.Windows.Forms.TextBox();
            this.regionlable = new System.Windows.Forms.Label();
            this.regionbox = new System.Windows.Forms.TextBox();
            this.postcodelable = new System.Windows.Forms.Label();
            this.postcodebox = new System.Windows.Forms.TextBox();
            this.emaillable = new System.Windows.Forms.Label();
            this.emailbox = new System.Windows.Forms.TextBox();
            this.phoneNumberlable = new System.Windows.Forms.Label();
            this.phonenumberbox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.idlable = new System.Windows.Forms.Label();
            this.useridbox = new System.Windows.Forms.TextBox();
            this.passwordlable = new System.Windows.Forms.Label();
            this.passwordbox1 = new System.Windows.Forms.TextBox();
            this.reEnterPasswordlable = new System.Windows.Forms.Label();
            this.passwordbox2 = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.notebox = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // namebox
            // 
            this.namebox.Location = new System.Drawing.Point(91, 52);
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(198, 20);
            this.namebox.TabIndex = 0;
            // 
            // namelable
            // 
            this.namelable.AutoSize = true;
            this.namelable.Location = new System.Drawing.Point(50, 55);
            this.namelable.Name = "namelable";
            this.namelable.Size = new System.Drawing.Size(39, 13);
            this.namelable.TabIndex = 1;
            this.namelable.Text = "Name*";
            // 
            // surnamelable
            // 
            this.surnamelable.AutoSize = true;
            this.surnamelable.Location = new System.Drawing.Point(36, 84);
            this.surnamelable.Name = "surnamelable";
            this.surnamelable.Size = new System.Drawing.Size(53, 13);
            this.surnamelable.TabIndex = 3;
            this.surnamelable.Text = "Surname*";
            // 
            // surnamebox
            // 
            this.surnamebox.Location = new System.Drawing.Point(91, 81);
            this.surnamebox.Name = "surnamebox";
            this.surnamebox.Size = new System.Drawing.Size(198, 20);
            this.surnamebox.TabIndex = 2;
            // 
            // addresslable
            // 
            this.addresslable.AutoSize = true;
            this.addresslable.Location = new System.Drawing.Point(40, 128);
            this.addresslable.Name = "addresslable";
            this.addresslable.Size = new System.Drawing.Size(49, 13);
            this.addresslable.TabIndex = 5;
            this.addresslable.Text = "Address*";
            // 
            // addressbox
            // 
            this.addressbox.Location = new System.Drawing.Point(91, 125);
            this.addressbox.Name = "addressbox";
            this.addressbox.Size = new System.Drawing.Size(198, 20);
            this.addressbox.TabIndex = 4;
            // 
            // towncitylable
            // 
            this.towncitylable.AutoSize = true;
            this.towncitylable.Location = new System.Drawing.Point(29, 166);
            this.towncitylable.Name = "towncitylable";
            this.towncitylable.Size = new System.Drawing.Size(60, 13);
            this.towncitylable.TabIndex = 9;
            this.towncitylable.Text = "Town/City*";
            // 
            // towncitybox
            // 
            this.towncitybox.Location = new System.Drawing.Point(91, 163);
            this.towncitybox.Name = "towncitybox";
            this.towncitybox.Size = new System.Drawing.Size(198, 20);
            this.towncitybox.TabIndex = 8;
            // 
            // regionlable
            // 
            this.regionlable.AutoSize = true;
            this.regionlable.Location = new System.Drawing.Point(44, 192);
            this.regionlable.Name = "regionlable";
            this.regionlable.Size = new System.Drawing.Size(41, 13);
            this.regionlable.TabIndex = 11;
            this.regionlable.Text = "Region";
            // 
            // regionbox
            // 
            this.regionbox.Location = new System.Drawing.Point(91, 189);
            this.regionbox.Name = "regionbox";
            this.regionbox.Size = new System.Drawing.Size(198, 20);
            this.regionbox.TabIndex = 10;
            // 
            // postcodelable
            // 
            this.postcodelable.AutoSize = true;
            this.postcodelable.Location = new System.Drawing.Point(36, 232);
            this.postcodelable.Name = "postcodelable";
            this.postcodelable.Size = new System.Drawing.Size(56, 13);
            this.postcodelable.TabIndex = 13;
            this.postcodelable.Text = "Postcode*";
            // 
            // postcodebox
            // 
            this.postcodebox.Location = new System.Drawing.Point(91, 229);
            this.postcodebox.Name = "postcodebox";
            this.postcodebox.Size = new System.Drawing.Size(198, 20);
            this.postcodebox.TabIndex = 12;
            // 
            // emaillable
            // 
            this.emaillable.AutoSize = true;
            this.emaillable.Location = new System.Drawing.Point(50, 288);
            this.emaillable.Name = "emaillable";
            this.emaillable.Size = new System.Drawing.Size(35, 13);
            this.emaillable.TabIndex = 15;
            this.emaillable.Text = "E-mail";
            // 
            // emailbox
            // 
            this.emailbox.Location = new System.Drawing.Point(91, 285);
            this.emailbox.Name = "emailbox";
            this.emailbox.Size = new System.Drawing.Size(198, 20);
            this.emailbox.TabIndex = 14;
            // 
            // phoneNumberlable
            // 
            this.phoneNumberlable.AutoSize = true;
            this.phoneNumberlable.Location = new System.Drawing.Point(7, 314);
            this.phoneNumberlable.Name = "phoneNumberlable";
            this.phoneNumberlable.Size = new System.Drawing.Size(82, 13);
            this.phoneNumberlable.TabIndex = 17;
            this.phoneNumberlable.Text = "Phone Number*";
            // 
            // phonenumberbox
            // 
            this.phonenumberbox.Location = new System.Drawing.Point(91, 311);
            this.phonenumberbox.Name = "phonenumberbox";
            this.phonenumberbox.Size = new System.Drawing.Size(198, 20);
            this.phonenumberbox.TabIndex = 16;
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.submitButton.Location = new System.Drawing.Point(558, 311);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(227, 68);
            this.submitButton.TabIndex = 18;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // idlable
            // 
            this.idlable.AutoSize = true;
            this.idlable.Location = new System.Drawing.Point(406, 55);
            this.idlable.Name = "idlable";
            this.idlable.Size = new System.Drawing.Size(47, 13);
            this.idlable.TabIndex = 20;
            this.idlable.Text = "User ID*";
            // 
            // useridbox
            // 
            this.useridbox.Location = new System.Drawing.Point(455, 52);
            this.useridbox.Name = "useridbox";
            this.useridbox.Size = new System.Drawing.Size(192, 20);
            this.useridbox.TabIndex = 19;
            // 
            // passwordlable
            // 
            this.passwordlable.AutoSize = true;
            this.passwordlable.Location = new System.Drawing.Point(396, 128);
            this.passwordlable.Name = "passwordlable";
            this.passwordlable.Size = new System.Drawing.Size(57, 13);
            this.passwordlable.TabIndex = 22;
            this.passwordlable.Text = "Password*";
            // 
            // passwordbox1
            // 
            this.passwordbox1.Location = new System.Drawing.Point(455, 121);
            this.passwordbox1.Name = "passwordbox1";
            this.passwordbox1.Size = new System.Drawing.Size(192, 20);
            this.passwordbox1.TabIndex = 21;
            // 
            // reEnterPasswordlable
            // 
            this.reEnterPasswordlable.AutoSize = true;
            this.reEnterPasswordlable.Location = new System.Drawing.Point(351, 150);
            this.reEnterPasswordlable.Name = "reEnterPasswordlable";
            this.reEnterPasswordlable.Size = new System.Drawing.Size(102, 13);
            this.reEnterPasswordlable.TabIndex = 24;
            this.reEnterPasswordlable.Text = "Re-Enter Password*";
            // 
            // passwordbox2
            // 
            this.passwordbox2.Location = new System.Drawing.Point(455, 147);
            this.passwordbox2.Name = "passwordbox2";
            this.passwordbox2.Size = new System.Drawing.Size(192, 20);
            this.passwordbox2.TabIndex = 23;
            // 
            // cancelButton
            // 
            this.cancelButton.BackColor = System.Drawing.Color.Teal;
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(325, 311);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(227, 68);
            this.cancelButton.TabIndex = 26;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // notebox
            // 
            this.notebox.AutoSize = true;
            this.notebox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notebox.ForeColor = System.Drawing.Color.Black;
            this.notebox.Location = new System.Drawing.Point(464, 387);
            this.notebox.Name = "notebox";
            this.notebox.Size = new System.Drawing.Size(163, 24);
            this.notebox.TabIndex = 27;
            this.notebox.Text = "* = Required Field";
            // 
            // registerRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(797, 420);
            this.Controls.Add(this.notebox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.reEnterPasswordlable);
            this.Controls.Add(this.passwordbox2);
            this.Controls.Add(this.passwordlable);
            this.Controls.Add(this.passwordbox1);
            this.Controls.Add(this.idlable);
            this.Controls.Add(this.useridbox);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.phoneNumberlable);
            this.Controls.Add(this.phonenumberbox);
            this.Controls.Add(this.emaillable);
            this.Controls.Add(this.emailbox);
            this.Controls.Add(this.postcodelable);
            this.Controls.Add(this.postcodebox);
            this.Controls.Add(this.regionlable);
            this.Controls.Add(this.regionbox);
            this.Controls.Add(this.towncitylable);
            this.Controls.Add(this.towncitybox);
            this.Controls.Add(this.addresslable);
            this.Controls.Add(this.addressbox);
            this.Controls.Add(this.surnamelable);
            this.Controls.Add(this.surnamebox);
            this.Controls.Add(this.namelable);
            this.Controls.Add(this.namebox);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(813, 458);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(813, 458);
            this.Name = "registerRequest";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register Request Form";
            this.Load += new System.EventHandler(this.registerRequest_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.Label namelable;
        private System.Windows.Forms.Label surnamelable;
        private System.Windows.Forms.TextBox surnamebox;
        private System.Windows.Forms.Label addresslable;
        private System.Windows.Forms.TextBox addressbox;
        private System.Windows.Forms.Label towncitylable;
        private System.Windows.Forms.TextBox towncitybox;
        private System.Windows.Forms.Label regionlable;
        private System.Windows.Forms.TextBox regionbox;
        private System.Windows.Forms.Label postcodelable;
        private System.Windows.Forms.TextBox postcodebox;
        private System.Windows.Forms.Label emaillable;
        private System.Windows.Forms.TextBox emailbox;
        private System.Windows.Forms.Label phoneNumberlable;
        private System.Windows.Forms.TextBox phonenumberbox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label idlable;
        private System.Windows.Forms.TextBox useridbox;
        private System.Windows.Forms.Label passwordlable;
        private System.Windows.Forms.TextBox passwordbox1;
        private System.Windows.Forms.Label reEnterPasswordlable;
        private System.Windows.Forms.TextBox passwordbox2;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Label notebox;
    }
}