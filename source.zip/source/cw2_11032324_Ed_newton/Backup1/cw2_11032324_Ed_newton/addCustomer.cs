﻿/* FEATURES
 * you can make a new customer
 * if any required fields are empty it will error and tell you 
 * exit send you back to the menu, you can also press esc to do that.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;                                  //DO NOT TOUCH
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace cw2_11032324_Ed_newton
{
    public partial class addCustomer : Form
    {
        String connectionString; // makes the connection to the datebase
        OleDbConnection con; // con can now be used to make a connection
        DataSet ds; // used to set data
        String sql; // used to set what table to open
        OleDbCommand cmd; // used to start a command
        OleDbDataAdapter da; // converts data 
        BindingSource bs; // saves new data

        string name;
        string surname;
        string address;
        string townCity;
        string region;   // strings that will save values from their corosponding text boxes when submit is pressed 
        string postCode;
        string email;
        string phoneNumber;

        bool correctFields; // these bool variables are used to tell the computer that all information is correct and can now be submited to the data base

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public addCustomer()
        {
            InitializeComponent();
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void cancelButton_Click(object sender, EventArgs e) // cancel button
        {
            this.Close(); // user has clicked cancel close window.
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void addCustomer_Load(object sender, EventArgs e) // code starts when window opens
        {
            connectionString = StaticConnectionString.connectionString; // set the right address for the database and conncetion string
            con = new OleDbConnection(connectionString); // con will conncet to the database address given

            con.Open(); // opens the conection
            ds = new DataSet(); // creates a new data set
            sql = "SELECT * FROM Customer"; // in the staff table
            cmd = con.CreateCommand(); // command given to make the new dataset
            da = new OleDbDataAdapter(sql, con); // makes sure the data entered is converted correctly
            da.Fill(ds, "Customer"); // gets the data base ready to enter new data
            bs = new BindingSource(); // saves the data
            bs.DataSource = ds.Tables["Customer"]; // saves the table
            con.Close(); // closes the connection
        }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void submitButton_Click(object sender, EventArgs e) // submit button
        {
            name = namebox.Text;
            surname = surnamebox.Text;  // set all value of strings to match that of the text boxes
            address = addressbox.Text;
            townCity = towncitybox.Text;
            region = regionbox.Text;
            postCode = postcodebox.Text;
            email = emailbox.Text;
            phoneNumber = phonenumberbox.Text;

            if (name.Length <= 0 || surname.Length <= 0 || address.Length <= 0 || townCity.Length <= 0 || postCode.Length <= 0 || phoneNumber.Length <= 0) // checked something has been enter in the required fields 
            {
                MessageBox.Show("A required field was empty. Try again please.", "ERROR", MessageBoxButtons.OK); // one or more have not 
                correctFields = false; // user can't progress 

            }
            else if (name.Length > 0 || surname.Length > 0 || address.Length > 0 || townCity.Length > 0 || postCode.Length > 0 || phoneNumber.Length > 0) // everything has something entered in it
            {
                correctFields = true; // the user can now progress
            }


            if (correctFields == true) // everything entered is correct and the information may now be saved.
            {

                con.Open(); // open a connection to the database

                // first finds the table and fields that the user wants to change/delete and sets the variable that the new information can be added too.
                System.Data.OleDb.OleDbCommand accessInsertCommand = new System.Data.OleDb.OleDbCommand("INSERT INTO Customer (Name, Surname, Address, Town, Region, Postcode, Email, PhoneNumber) VALUES (@Name, @Surname, @Address, @Town, @Region, @Postcode, @Email, @PhoneNumber)", con);
                accessInsertCommand.Parameters.AddWithValue("Name", name); // the same happens for all fields within the database 
                accessInsertCommand.Parameters.AddWithValue("Surname", surname);
                accessInsertCommand.Parameters.AddWithValue("Address", address);
                accessInsertCommand.Parameters.AddWithValue("Town", townCity);
                accessInsertCommand.Parameters.AddWithValue("Region", region);
                accessInsertCommand.Parameters.AddWithValue("Postcode", postCode);
                accessInsertCommand.Parameters.AddWithValue("Email", email);
                accessInsertCommand.Parameters.AddWithValue("PhoneNumber", phoneNumber);

                da.InsertCommand = accessInsertCommand; // gets the command to add and save the data
                da.InsertCommand.ExecuteNonQuery(); // saves it

                con.Close(); // closes the connnection

                //clears all the tables in the dataset
                ds.Clear();

                //refills the staff table
                da.Fill(ds, "Customer");

                MessageBox.Show("Record Added");
                this.Close(); // closes the window
            }
        }
    }
}
