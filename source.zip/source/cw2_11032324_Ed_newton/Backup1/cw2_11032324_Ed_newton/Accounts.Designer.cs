﻿namespace cw2_11032324_Ed_newton
{
    partial class Accounts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Accounts));
            this.IDlabel = new System.Windows.Forms.Label();
            this.customerIDbox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.newaccountsButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.nextButton = new System.Windows.Forms.Button();
            this.statuslb = new System.Windows.Forms.Label();
            this.overdraftlb = new System.Windows.Forms.Label();
            this.overdraftbox = new System.Windows.Forms.TextBox();
            this.balancelb = new System.Windows.Forms.Label();
            this.balancebox = new System.Windows.Forms.TextBox();
            this.typelb = new System.Windows.Forms.Label();
            this.accountnumberlb = new System.Windows.Forms.Label();
            this.accountnumberbox = new System.Windows.Forms.TextBox();
            this.accountTypebox = new System.Windows.Forms.ComboBox();
            this.accountlockedbox = new System.Windows.Forms.ComboBox();
            this.deletebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // IDlabel
            // 
            this.IDlabel.AutoSize = true;
            this.IDlabel.Location = new System.Drawing.Point(90, 15);
            this.IDlabel.Name = "IDlabel";
            this.IDlabel.Size = new System.Drawing.Size(65, 13);
            this.IDlabel.TabIndex = 88;
            this.IDlabel.Text = "Customer ID";
            // 
            // customerIDbox
            // 
            this.customerIDbox.Location = new System.Drawing.Point(161, 12);
            this.customerIDbox.Name = "customerIDbox";
            this.customerIDbox.ReadOnly = true;
            this.customerIDbox.Size = new System.Drawing.Size(69, 20);
            this.customerIDbox.TabIndex = 87;
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(327, 229);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(175, 49);
            this.exitButton.TabIndex = 86;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // newaccountsButton
            // 
            this.newaccountsButton.BackColor = System.Drawing.Color.Teal;
            this.newaccountsButton.Location = new System.Drawing.Point(327, 174);
            this.newaccountsButton.Name = "newaccountsButton";
            this.newaccountsButton.Size = new System.Drawing.Size(175, 49);
            this.newaccountsButton.TabIndex = 85;
            this.newaccountsButton.Text = "New Account";
            this.newaccountsButton.UseVisualStyleBackColor = false;
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.saveButton.Location = new System.Drawing.Point(327, 67);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(175, 49);
            this.saveButton.TabIndex = 84;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // nextButton
            // 
            this.nextButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.nextButton.Location = new System.Drawing.Point(327, 12);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(175, 49);
            this.nextButton.TabIndex = 83;
            this.nextButton.Text = "Next";
            this.nextButton.UseVisualStyleBackColor = false;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // statuslb
            // 
            this.statuslb.AutoSize = true;
            this.statuslb.Location = new System.Drawing.Point(13, 213);
            this.statuslb.Name = "statuslb";
            this.statuslb.Size = new System.Drawing.Size(86, 13);
            this.statuslb.TabIndex = 76;
            this.statuslb.Text = "Account Locked";
            // 
            // overdraftlb
            // 
            this.overdraftlb.AutoSize = true;
            this.overdraftlb.Location = new System.Drawing.Point(24, 175);
            this.overdraftlb.Name = "overdraftlb";
            this.overdraftlb.Size = new System.Drawing.Size(75, 13);
            this.overdraftlb.TabIndex = 74;
            this.overdraftlb.Text = "Overdraft Limit";
            // 
            // overdraftbox
            // 
            this.overdraftbox.Location = new System.Drawing.Point(105, 172);
            this.overdraftbox.Name = "overdraftbox";
            this.overdraftbox.Size = new System.Drawing.Size(198, 20);
            this.overdraftbox.TabIndex = 73;
            // 
            // balancelb
            // 
            this.balancelb.AutoSize = true;
            this.balancelb.Location = new System.Drawing.Point(16, 137);
            this.balancelb.Name = "balancelb";
            this.balancelb.Size = new System.Drawing.Size(83, 13);
            this.balancelb.TabIndex = 72;
            this.balancelb.Text = "Current Balance";
            // 
            // balancebox
            // 
            this.balancebox.Location = new System.Drawing.Point(105, 134);
            this.balancebox.Name = "balancebox";
            this.balancebox.ReadOnly = true;
            this.balancebox.Size = new System.Drawing.Size(198, 20);
            this.balancebox.TabIndex = 71;
            // 
            // typelb
            // 
            this.typelb.AutoSize = true;
            this.typelb.Location = new System.Drawing.Point(25, 93);
            this.typelb.Name = "typelb";
            this.typelb.Size = new System.Drawing.Size(74, 13);
            this.typelb.TabIndex = 70;
            this.typelb.Text = "Account Type";
            // 
            // accountnumberlb
            // 
            this.accountnumberlb.AutoSize = true;
            this.accountnumberlb.Location = new System.Drawing.Point(12, 64);
            this.accountnumberlb.Name = "accountnumberlb";
            this.accountnumberlb.Size = new System.Drawing.Size(87, 13);
            this.accountnumberlb.TabIndex = 68;
            this.accountnumberlb.Text = "Account Number";
            // 
            // accountnumberbox
            // 
            this.accountnumberbox.Location = new System.Drawing.Point(105, 61);
            this.accountnumberbox.Name = "accountnumberbox";
            this.accountnumberbox.ReadOnly = true;
            this.accountnumberbox.Size = new System.Drawing.Size(198, 20);
            this.accountnumberbox.TabIndex = 67;
            // 
            // accountTypebox
            // 
            this.accountTypebox.FormattingEnabled = true;
            this.accountTypebox.Location = new System.Drawing.Point(106, 93);
            this.accountTypebox.Name = "accountTypebox";
            this.accountTypebox.Size = new System.Drawing.Size(197, 21);
            this.accountTypebox.TabIndex = 89;
            // 
            // accountlockedbox
            // 
            this.accountlockedbox.FormattingEnabled = true;
            this.accountlockedbox.Location = new System.Drawing.Point(105, 209);
            this.accountlockedbox.Name = "accountlockedbox";
            this.accountlockedbox.Size = new System.Drawing.Size(197, 21);
            this.accountlockedbox.TabIndex = 90;
            // 
            // deletebutton
            // 
            this.deletebutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.deletebutton.Location = new System.Drawing.Point(327, 122);
            this.deletebutton.Name = "deletebutton";
            this.deletebutton.Size = new System.Drawing.Size(175, 49);
            this.deletebutton.TabIndex = 91;
            this.deletebutton.Text = "Delete";
            this.deletebutton.UseVisualStyleBackColor = false;
            this.deletebutton.Click += new System.EventHandler(this.deletebutton_Click);
            // 
            // Accounts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(520, 290);
            this.Controls.Add(this.deletebutton);
            this.Controls.Add(this.accountlockedbox);
            this.Controls.Add(this.accountTypebox);
            this.Controls.Add(this.IDlabel);
            this.Controls.Add(this.customerIDbox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.newaccountsButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.statuslb);
            this.Controls.Add(this.overdraftlb);
            this.Controls.Add(this.overdraftbox);
            this.Controls.Add(this.balancelb);
            this.Controls.Add(this.balancebox);
            this.Controls.Add(this.typelb);
            this.Controls.Add(this.accountnumberlb);
            this.Controls.Add(this.accountnumberbox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(536, 328);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(536, 328);
            this.Name = "Accounts";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Accounts";
            this.Load += new System.EventHandler(this.Accounts_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label IDlabel;
        public System.Windows.Forms.TextBox customerIDbox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button newaccountsButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Label statuslb;
        private System.Windows.Forms.Label overdraftlb;
        private System.Windows.Forms.TextBox overdraftbox;
        private System.Windows.Forms.Label balancelb;
        private System.Windows.Forms.TextBox balancebox;
        private System.Windows.Forms.Label typelb;
        private System.Windows.Forms.Label accountnumberlb;
        private System.Windows.Forms.TextBox accountnumberbox;
        private System.Windows.Forms.ComboBox accountTypebox;
        private System.Windows.Forms.ComboBox accountlockedbox;
        private System.Windows.Forms.Button deletebutton;

    }
}