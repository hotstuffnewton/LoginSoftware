﻿/* FEATURES
 * clicking log in with out entering anything will cause an error and the program will tell you about it.
 * a correct user and password will give you accsess to the database
 * the regeiter button takes you to a form where you can make an accout to log in with.
 * exit closes the program.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;                             // Code imports. DO NOT TOUCH!
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
namespace cw2_11032324_Ed_newton
{
    public partial class LogInScreen : Form
    {

        String connectionString; // makes the connection to the datebase
        OleDbConnection con; // con can now be used to make a connection
        DataSet ds; // used to set data
        String sql; // used to set what table to open
        OleDbCommand cmd; // used to start a command
        OleDbDataAdapter da; // converts data 
        BindingSource bs; // saves new data

        bool correctUserId; // if both are true then the user can log in
        bool correctPassword;

        string password; // holds the value entered in by the user in the password box
        string userId; //holds the value entered in by the user in the user id box

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public LogInScreen()
        {
            InitializeComponent();
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void logInButton_Click(object sender, EventArgs e) // log in button
        {
            password = passWordtextbox.Text; // saves the values
            userId = userIDtextbox.Text;

            correctUserId = false; // user can't progress unless they are true
            correctPassword = false;

            if (password.Length <= 0 || userId.Length <= 0) // nothing entered in password or userid
            {
                MessageBox.Show("A required field was empty. Try again please.", "ERROR", MessageBoxButtons.OK); // show error box

            }
            else // something was entered in both boxes
            {
                OleDbCommand command = new OleDbCommand(); // new command
                command.CommandText = "SELECT staffID, AccPassword FROM staff"; // get the staff id AND password collum from the staff table
                command.Connection = con; // set var


                con.Open(); // open the conncetion
                OleDbDataReader dr = command.ExecuteReader(); // set up a datareader

                while (dr.Read()) // while the data is being read
                {
                    for (int i = 0; i < bs.Count; i++) // create a loop
                    {
                        // if the user id and password entered in by the user is the same as one of the DB entries they can log in
                        if (userId == dr["staffID"].ToString() && password == dr["AccPassword"].ToString()) 
                        {
                            correctUserId = true; // stops an error from being caused
                            correctPassword = true;
                        } 
                    }
                }

                con.Close(); // close connection either because id is correct or incorrect 
            }

            if (correctPassword == true && correctUserId == true) // the log in button has been clicked on AND the id and password are correct
            {
                passWordtextbox.Text = null;
                userIDtextbox.Text = null; // clears all values for security reasons
                MenuScreen vc; 
                vc = new MenuScreen(userId); // open up the menu window /log in AND takes the value of the userId string with it.
                vc.ShowDialog();
            }
            else if (correctPassword == false && correctUserId == false && password.Length > 0 && userId.Length > 0) // what was entered was incorrect
            {
                MessageBox.Show("The Password or User ID was incorrect. Try again please.", "ERROR", MessageBoxButtons.OK); // show error box
            }
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void exitButton_Click(object sender, EventArgs e) // exit button
        {
            if (MessageBox.Show("Are you sure you want close this program?", "Exit", MessageBoxButtons.YesNo) == DialogResult.Yes) // exit button has been clicked on.
            { // computer double checks the user wants to exit the program with a message box.
                Application.Exit(); // user has clicked ok, end program.
            }
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void registerButton_Click(object sender, EventArgs e) // register button
        { // button has been clicked on, form will pop to request an admin account 
            registerRequest vc; 
            vc = new registerRequest();
            vc.ShowDialog();
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LogInScreen_Load(object sender, EventArgs e) // starts when the program for this window starts
        {
            connectionString = StaticConnectionString.connectionString; // set the right address for the database and conncetion string
            con = new OleDbConnection(connectionString); // con will conncet to the database address given

            con.Open(); // opens the conection
            ds = new DataSet(); // creates a new data set
            sql = "SELECT * FROM staff"; // in the staff table
            cmd = con.CreateCommand(); // command given to make the new dataset
            da = new OleDbDataAdapter(sql, con); // makes sure the data entered is converted correctly
            da.Fill(ds, "staff"); // gets the data base ready to enter new data
            bs = new BindingSource(); // saves the data
            bs.DataSource = ds.Tables["staff"]; // saves the table
            con.Close(); // closes the connection
        }


    }
}
